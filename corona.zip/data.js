$(document).ready(function() {
  $("#mytable").DataTable({
    drawCallback: function() {
      var api = this.api();
      $(api.table().footer()).html(
        api
          .column(4, { page: "current" })
          .data()
          .sum()
      );
    },
    ajax: {
      async: true,
      crossDomain: true,
      url:
        "https://coronavirus-monitor.p.rapidapi.com/coronavirus/cases_by_country.php",
      method: "GET",
      headers: {
        "x-rapidapi-host": "coronavirus-monitor.p.rapidapi.com",
        "x-rapidapi-key": "10c107a9a3msh74da33361403f71p13c64ajsn3b19de1e4ea1"
      },
      dataSrc: "countries_stat",
      scrollY: 200,
      deferRender: true,
      scroller: true
    },
    columns: [
      { data: "country_name" },
      { data: "cases" },
      { data: "deaths" },
      { data: "region" },
      { data: "total_recovered" },
      { data: "new_deaths" },
      { data: "new_cases" },
      { data: "serious_critical" },
      { data: "active_cases" },
      { data: "total_cases_per_1m_population" }
    ]
  });
});
