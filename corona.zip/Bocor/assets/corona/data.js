$(document).ready(function() {
  $("#mytable").DataTable({
    ajax: {
      async: true,
      crossDomain: true,
      url:
        "https://coronavirus-monitor.p.rapidapi.com/coronavirus/cases_by_country.php",
      method: "GET",
      headers: {
        "x-rapidapi-host": "coronavirus-monitor.p.rapidapi.com",
        "x-rapidapi-key": "10c107a9a3msh74da33361403f71p13c64ajsn3b19de1e4ea1"
      },
      dataSrc: "countries_stat"
    },
    scrollY: 420,
    deferRender: true,
    scrollCollapse: true,
    paging: false,
    scroller: true,
    columns: [
      { data: "country_name" },
      { data: "cases" },
      { data: "deaths" },
      { data: "total_recovered" },
      { data: "new_deaths" },
      { data: "new_cases" },
      { data: "serious_critical" },
      { data: "active_cases" },
      { data: "total_cases_per_1m_population" }
    ],
    aaSorting: [[2, "desc"]]
  });
  /*
  $("#mytablex").DataTable({
    ajax: {
      async: true,
      crossDomain: true,
      url:
        "https://coronavirus-monitor.p.rapidapi.com/coronavirus/cases_by_particular_country.php?country=india",
      method: "GET",
      headers: {
        "x-rapidapi-host": "coronavirus-monitor.p.rapidapi.com",
        "x-rapidapi-key": "10c107a9a3msh74da33361403f71p13c64ajsn3b19de1e4ea1"
      },
      dataSrc: "stat_by_country"
    },
    scrollY: 420,
    deferRender: true,
    scrollCollapse: true,
    paging: false,
    scroller: true,
    columns: [
      { data: "total_cases" },
      { data: "new_cases" },
      { data: "active_cases" },
      { data: "total_deaths" },
      { data: "new_deaths" },
      { data: "total_recovered" },
      { data: "record_date" }
    ]
  });
  */
});

Highcharts.chart("containerx", {
  chart: {
    type: "line"
  },
  title: {
    text: "How COVID-19 Spread (Italy Vs China)"
  },
  subtitle: {
    text: "Source: WHO"
  },
  xAxis: {
    categories: ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]
  },
  yAxis: {
    title: {
      text: "Cases"
    }
  },
  plotOptions: {
    line: {
      dataLabels: {
        enabled: true
      },
      enableMouseTracking: false
    }
  },
  series: [
    {
      name: "Italy",
      data: [3, 3, 3, 3, 650, 5378]
    },
    {
      name: "China",
      data: [10, 20, 45, 14213, 79824, 81054]
    }
  ]
});

//hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh
Highcharts.chart("container2", {
  chart: {
    type: "area"
  },
  title: {
    text: "Historic and Estimated Worldwide Population Distribution by Region"
  },
  subtitle: {
    text: "Source: Wikipedia.org"
  },
  xAxis: {
    categories: ["1750", "1800", "1850", "1900", "1950", "1999", "2050"],
    tickmarkPlacement: "on",
    title: {
      enabled: false
    }
  },
  yAxis: {
    labels: {
      format: "{value}%"
    },
    title: {
      enabled: false
    }
  },
  tooltip: {
    pointFormat:
      '<span style="color:{series.color}">{series.name}</span>: <b>{point.percentage:.1f}%</b> ({point.y:,.0f} millions)<br/>',
    split: true
  },
  plotOptions: {
    area: {
      stacking: "percent",
      lineColor: "#ffffff",
      lineWidth: 1,
      marker: {
        lineWidth: 1,
        lineColor: "#ffffff"
      },
      accessibility: {
        pointDescriptionFormatter: function(point) {
          function round(x) {
            return Math.round(x * 100) / 100;
          }
          return (
            point.index +
            1 +
            ", " +
            point.category +
            ", " +
            point.y +
            " millions, " +
            round(point.percentage) +
            "%, " +
            point.series.name
          );
        }
      }
    }
  },
  series: [
    {
      name: "Asia",
      data: [502, 635, 809, 947, 1402, 3634, 5268]
    },
    {
      name: "Africa",
      data: [106, 107, 111, 133, 221, 767, 1766]
    },
    {
      name: "Europe",
      data: [163, 203, 276, 408, 547, 729, 628]
    },
    {
      name: "America",
      data: [18, 31, 54, 156, 339, 818, 1201]
    },
    {
      name: "Oceania",
      data: [2, 2, 2, 6, 13, 30, 46]
    }
  ]
});
//
Highcharts.chart("containere", {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: "pie"
  },
  title: {
    text: "COVID-19"
  },
  tooltip: {
    pointFormat: "{series.name}: <b>{point.percentage:.1f}%</b>"
  },
  accessibility: {
    point: {
      valueSuffix: "%"
    }
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: "pointer",
      dataLabels: {
        enabled: true,
        format: "<b>{point.name}</b>: {point.percentage:.1f} %"
      }
    }
  },
  series: [
    {
      name: "Brands",
      colorByPoint: true,
      data: [
        {
          name: "Chrome",
          y: 61.41,
          sliced: true,
          selected: true
        },
        {
          name: "Internet Explorer",
          y: 11.84
        },
        {
          name: "Firefox",
          y: 10.85
        },
        {
          name: "Edge",
          y: 4.67
        },
        {
          name: "Safari",
          y: 4.18
        },
        {
          name: "Sogou Explorer",
          y: 1.64
        },
        {
          name: "Opera",
          y: 1.6
        },
        {
          name: "QQ",
          y: 1.2
        },
        {
          name: "Other",
          y: 2.61
        }
      ]
    }
  ]
});
// Set up the chart
var chart = new Highcharts.Chart({
  chart: {
    renderTo: "container1",
    type: "column",
    options3d: {
      enabled: true,
      alpha: 15,
      beta: 15,
      depth: 50,
      viewDistance: 25
    }
  },
  title: {
    text: "COVID-19"
  },
  subtitle: {
    text: "Test options by dragging the sliders below"
  },
  plotOptions: {
    column: {
      depth: 25
    }
  },
  series: [
    {
      data: [
        29.9,
        71.5,
        106.4,
        129.2,
        144.0,
        176.0,
        135.6,
        148.5,
        216.4,
        194.1,
        95.6,
        54.4
      ]
    }
  ]
});

function showValues() {
  $("#alpha-value").html(chart.options.chart.options3d.alpha);
  $("#beta-value").html(chart.options.chart.options3d.beta);
  $("#depth-value").html(chart.options.chart.options3d.depth);
}

// Activate the sliders
$("#sliders input").on("input change", function() {
  chart.options.chart.options3d[this.id] = parseFloat(this.value);
  showValues();
  chart.redraw(false);
});

showValues();
